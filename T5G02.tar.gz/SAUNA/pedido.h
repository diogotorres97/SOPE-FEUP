
struct Pedido{
	int id;
	char g;
	int time;
	int rNo;
};
